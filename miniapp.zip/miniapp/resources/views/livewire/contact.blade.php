<div>
    <p class="text-xl md:font-bold pb-3">New Contact</p>
	<div class="py">
		<button type="button" wire:click="login">
		
		</button>
	</div>
</div>
