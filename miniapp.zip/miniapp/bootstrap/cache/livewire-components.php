<?php return array (
  'calculator' => 'App\\Http\\Livewire\\Calculator',
  'contact' => 'App\\Http\\Livewire\\Contact',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'dropcascading' => 'App\\Http\\Livewire\\Dropcascading',
  'mytodo' => 'App\\Http\\Livewire\\Mytodo',
);