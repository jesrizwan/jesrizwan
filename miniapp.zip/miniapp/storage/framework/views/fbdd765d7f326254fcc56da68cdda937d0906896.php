<div>
    <div class="d-flex shadow-0 bg-grey-600 border-1">
		<h4 class="text-lg text-blue-600">Hello, Sam</h4>
	</div>
</div>
<?php /**PATH C:\miniapp\resources\views/livewire/dropcascading.blade.php ENDPATH**/ ?>