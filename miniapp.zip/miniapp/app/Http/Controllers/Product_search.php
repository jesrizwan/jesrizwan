<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Product_search extends Controller
{
    //
}
